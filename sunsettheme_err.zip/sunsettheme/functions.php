<?php
/**
 * Wordpress Function
 *
 * @package sunsettheme
 * @since 1.0
 * @version 1.0
 */
require_once get_template_directory() . '/inc/cleanup.php';
require_once get_template_directory() . '/inc/function-admin.php';
require_once get_template_directory() . '/inc/enqueue.php';
require_once get_template_directory() . '/inc/theme-support.php';
require_once get_template_directory() . '/inc/custom-post-type.php';
require_once get_template_directory() . '/inc/walker.php';
require_once get_template_directory() . '/inc/ajax.php';
