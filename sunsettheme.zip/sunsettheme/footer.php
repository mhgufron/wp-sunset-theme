<?php
/**
 * This is a template for the footer
 *
 * @package sunsettheme
 * @since 1.0
 * @version 1.0
 */

 ?>

 <footer class="sunset-footer text-center"></footer>

<?php wp_footer(); ?>
</body>
</html>
